Data downloaded here: http://www.worldclimate.com/


* Use the top left search bar
* Temp is 24hr avg temp
* Rain is avg rainfall